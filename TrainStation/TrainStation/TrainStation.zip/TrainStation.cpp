#include <iostream>
#include "TrainSystemApp.h"

int main()
{
    TrainSystemApp app;
    app.run();
}

