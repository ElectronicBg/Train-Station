#pragma once
#include "DiscountCard.h"
#include "AgeCard.h"
#include "RouteCard.h"
#include "DistanceCard.h"
#include "MyString.h"


void saveCardToTextFile(const DiscountCard& card, const MyString& filename);

